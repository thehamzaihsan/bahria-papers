 SELECT ENAME, ROUND(Months_between(sysdate,HIREDATE),0) "MonthsWorked"
 FROM EMP
ORDER BY ENAME ASC
/
