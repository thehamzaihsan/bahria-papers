SELECT ENAME || ' earns ' || sal ||' monthly but want ' || 3 * (SAL) AS "DREAM SALARY" FROM EMP
/
