SELECT
EMPNO "Employee_Number",
ENAME,SAL,ROUND(SAL*(15.5/100),0) "New Sal"
FROM EMP
/
